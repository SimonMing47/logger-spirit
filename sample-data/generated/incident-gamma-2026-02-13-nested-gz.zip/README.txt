incident-gamma-2026-02-13-nested-gz
This sample includes nested zip -> zip -> zip.gz -> zip -> *.log.gz/*.json.gz and plain *.log.gz files.
Use it to verify recursive extraction of nested zip + gzip single-file payloads.
